#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  ReconKit — Lanzador principal
#  Uso: ./run.sh [--port 8000] [--host 127.0.0.1]
# ═══════════════════════════════════════════════════════════

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'

HOST="127.0.0.1"
PORT="8000"

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --port) PORT="$2"; shift ;;
        --host) HOST="$2"; shift ;;
    esac
    shift
done

cd "$(dirname "$0")"

# Primera ejecución → instalar deps
if [ ! -f ".installed" ]; then
    echo -e "${YELLOW}Primera ejecución detectada — instalando dependencias...${NC}"
    bash install.sh
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         ReconKit — Bug Bounty Intel          ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Web UI:${NC}  http://${HOST}:${PORT}"
echo -e "  ${CYAN}API:${NC}     http://${HOST}:${PORT}/docs"
echo -e "  ${CYAN}Logs:${NC}    ./audits/"
echo ""
echo -e "  Pulsa ${YELLOW}Ctrl+C${NC} para detener"
echo ""

# Lanzar uvicorn
python3 -m uvicorn app:app --host "$HOST" --port "$PORT" --log-level warning
