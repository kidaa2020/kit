# ReconKit — Bug Bounty Intelligence Tool

Herramienta web + terminal para automatizar el workflow de recon en auditorías HackerOne.

## Requisitos previos

- Linux (Kali, Ubuntu, Parrot recomendados)
- Python 3.8+
- Go 1.20+ (para herramientas de ProjectDiscovery)

## Instalación y arranque

```bash
# Clonar / copiar el directorio
cd recon-tool/

# Dar permisos
chmod +x run.sh install.sh

# Arrancar (instala dependencias automáticamente en primera ejecución)
./run.sh

# Abrir en el navegador
# http://127.0.0.1:8000
```

## Herramientas que instala automáticamente

| Herramienta | Fuente | Para qué |
|------------|--------|----------|
| subfinder | ProjectDiscovery | Enumeración pasiva de subdominios |
| assetfinder | tomnomnom | Subdominios adicionales |
| httpx | ProjectDiscovery | Filtrar subdominios vivos |
| katana | ProjectDiscovery | Crawling y extracción de JS |
| gau | lc | URLs históricas (wayback, etc.) |
| nuclei | ProjectDiscovery | Detección de vulns en JS |
| dnsx | ProjectDiscovery | Resolución DNS masiva |
| nmap | apt | Escaneo de puertos |
| ffuf | apt | Fuzzing de directorios |
| whatweb | apt | Detección de tecnologías |

## Módulos disponibles

### 🌐 Subdominios
- subfinder + assetfinder + crt.sh API
- Resolución y filtrado con httpx
- Sin Amass (demasiado lento para bug bounty)

### 🔌 Puertos
- **fast**: top 100 puertos, T4
- **full**: todos los puertos, T4
- **stealth**: SYN scan, T2
- **services**: detección completa de servicios

### ⚡ JavaScript
- Descarga automática de todos los JS del target
- Extracción de: API keys, tokens, secrets, AWS keys, DB strings
- Extracción de endpoints y rutas de API
- Análisis con nuclei (plantillas exposures/)

### 🔍 Análisis Web
- Headers de seguridad ausentes
- Detección de tecnologías (whatweb)
- Fuzzing de directorios (ffuf + SecLists)

## Estructura de resultados

```
audits/
└── target.com/
    └── 2026-08-30_14-32/
        ├── SUMMARY.md          ← Resumen exportable para write-up
        ├── subdomains_raw.txt
        ├── subdomains_alive.txt
        ├── ports.txt
        ├── ports.xml
        ├── js_urls.txt
        ├── js_files/           ← JS descargados
        ├── secrets.txt         ← Secrets encontrados
        ├── endpoints.txt       ← Endpoints extraídos
        ├── technologies.txt
        ├── headers.txt
        ├── fuzz_results.txt
        └── nuclei_js.txt
```

## Uso con puerto personalizado

```bash
./run.sh --port 9090 --host 0.0.0.0
```
