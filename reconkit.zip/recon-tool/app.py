#!/usr/bin/env python3
"""
ReconKit - Bug Bounty Intelligence Tool
Backend FastAPI con WebSockets para output en tiempo real
"""

import asyncio
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import aiofiles
import aiohttp
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="ReconKit")

AUDITS_DIR = Path("audits")
AUDITS_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────
# Utilidades
# ─────────────────────────────────────────────

async def stream_command(ws: WebSocket, cmd: str, cwd: str = None):
    """Ejecuta un comando y hace stream de output por WebSocket."""
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        cwd=cwd,
    )
    async for line in proc.stdout:
        text = line.decode("utf-8", errors="replace").rstrip()
        if text:
            await ws.send_json({"type": "output", "data": text})
    await proc.wait()
    return proc.returncode


async def send_status(ws: WebSocket, msg: str, level: str = "info"):
    await ws.send_json({"type": "status", "level": level, "data": msg})


async def send_summary_item(ws: WebSocket, key: str, value):
    await ws.send_json({"type": "summary_item", "key": key, "value": value})


def get_audit_dir(target: str) -> Path:
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M")
    safe = re.sub(r"[^\w\-.]", "_", target)
    d = AUDITS_DIR / safe / date_str
    d.mkdir(parents=True, exist_ok=True)
    return d


# ─────────────────────────────────────────────
# Módulos de recon
# ─────────────────────────────────────────────

async def run_subdomain_enum(ws: WebSocket, target: str, audit_dir: Path) -> dict:
    await send_status(ws, f"[+] Iniciando enumeración de subdominios para {target}", "info")
    results = {"subdomains_found": 0, "subdomains_alive": 0, "files": []}
    
    subs_file = audit_dir / "subdomains_raw.txt"
    alive_file = audit_dir / "subdomains_alive.txt"

    # --- subfinder ---
    if await tool_exists("subfinder"):
        await send_status(ws, "  → Ejecutando subfinder...", "info")
        await stream_command(ws, f"subfinder -d {target} -silent -o {subs_file}")
    else:
        await send_status(ws, "  ⚠ subfinder no encontrado, saltando", "warn")

    # --- assetfinder ---
    if await tool_exists("assetfinder"):
        await send_status(ws, "  → Ejecutando assetfinder...", "info")
        tmp = audit_dir / "assetfinder_tmp.txt"
        await stream_command(ws, f"assetfinder --subs-only {target} | tee {tmp}")
        await stream_command(ws, f"cat {tmp} >> {subs_file} && sort -u {subs_file} -o {subs_file}")

    # --- crt.sh ---
    await send_status(ws, "  → Consultando crt.sh...", "info")
    try:
        async with aiohttp.ClientSession() as session:
            url = f"https://crt.sh/?q=%.{target}&output=json"
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.json(content_type=None)
                    crt_subs = {
                        entry["name_value"].replace("*.", "")
                        for entry in data
                        if target in entry.get("name_value", "")
                    }
                    with open(subs_file, "a") as f:
                        for s in crt_subs:
                            f.write(s + "\n")
                    await ws.send_json({"type": "output", "data": f"  crt.sh encontró {len(crt_subs)} entradas"})
    except Exception as e:
        await send_status(ws, f"  ⚠ crt.sh falló: {e}", "warn")

    # Deduplicar
    if subs_file.exists():
        await stream_command(ws, f"sort -u {subs_file} -o {subs_file}")
        count = sum(1 for _ in open(subs_file) if _.strip())
        results["subdomains_found"] = count
        await send_status(ws, f"  ✔ {count} subdominios únicos encontrados", "success")

    # --- httpx para filtrar vivos ---
    if await tool_exists("httpx") and subs_file.exists():
        await send_status(ws, "  → Comprobando subdominios vivos con httpx...", "info")
        await stream_command(
            ws,
            f"httpx -l {subs_file} -silent -o {alive_file} -status-code -title -tech-detect",
        )
        if alive_file.exists():
            alive_count = sum(1 for _ in open(alive_file) if _.strip())
            results["subdomains_alive"] = alive_count
            await send_status(ws, f"  ✔ {alive_count} subdominios vivos", "success")
            results["files"].append(str(alive_file))

    results["files"].append(str(subs_file))
    return results


async def run_port_scan(ws: WebSocket, target: str, audit_dir: Path, mode: str = "fast") -> dict:
    await send_status(ws, f"[+] Iniciando escaneo de puertos ({mode})...", "info")
    results = {"ports_open": 0, "interesting_services": [], "files": []}

    out_file = audit_dir / "ports.txt"
    xml_file = audit_dir / "ports.xml"

    profiles = {
        "fast":     f"nmap -T4 -F --open -oN {out_file} -oX {xml_file} {target}",
        "full":     f"nmap -T4 -p- --open -sV -oN {out_file} -oX {xml_file} {target}",
        "stealth":  f"nmap -sS -T2 --open -oN {out_file} -oX {xml_file} {target}",
        "services": f"nmap -T4 -p- --open -sV -sC -oN {out_file} -oX {xml_file} {target}",
    }

    if not await tool_exists("nmap"):
        await send_status(ws, "  ✗ nmap no encontrado", "error")
        return results

    cmd = profiles.get(mode, profiles["fast"])
    await stream_command(ws, cmd)

    if out_file.exists():
        content = out_file.read_text()
        open_ports = re.findall(r"(\d+)/tcp\s+open", content)
        results["ports_open"] = len(open_ports)

        interesting = []
        interesting_ports = {"8080", "8443", "9200", "6379", "27017", "5432", "3306", "2375", "4243", "9000", "8888", "7777", "4444"}
        for p in open_ports:
            if p in interesting_ports:
                interesting.append(p)

        results["interesting_services"] = interesting
        results["files"].append(str(out_file))
        await send_status(ws, f"  ✔ {len(open_ports)} puertos abiertos encontrados", "success")
        if interesting:
            await send_status(ws, f"  ⚠ Puertos interesantes: {', '.join(interesting)}", "warn")

    return results


async def run_js_analysis(ws: WebSocket, target: str, audit_dir: Path) -> dict:
    await send_status(ws, "[+] Iniciando descarga y análisis de JavaScript...", "info")
    results = {"js_files": 0, "secrets_found": 0, "endpoints_found": 0, "files": []}

    js_dir = audit_dir / "js_files"
    js_dir.mkdir(exist_ok=True)
    js_list = audit_dir / "js_urls.txt"
    secrets_file = audit_dir / "secrets.txt"
    endpoints_file = audit_dir / "endpoints.txt"

    # Extraer URLs de JS con gau + katana
    await send_status(ws, "  → Buscando archivos JS del target...", "info")
    
    if await tool_exists("gau"):
        await stream_command(ws, f"gau {target} --blacklist png,jpg,gif,svg,woff,ttf | grep '\\.js' | sort -u | tee {js_list}")
    
    if await tool_exists("katana"):
        tmp_katana = audit_dir / "katana_js.txt"
        await stream_command(ws, f"katana -u https://{target} -silent -jc | grep '\\.js' | tee {tmp_katana}")
        if tmp_katana.exists():
            await stream_command(ws, f"cat {tmp_katana} >> {js_list} && sort -u {js_list} -o {js_list}")

    if not js_list.exists() or js_list.stat().st_size == 0:
        await send_status(ws, "  ⚠ No se encontraron archivos JS o gau/katana no disponibles", "warn")
        return results

    js_count = sum(1 for _ in open(js_list) if _.strip())
    results["js_files"] = js_count
    await send_status(ws, f"  ✔ {js_count} archivos JS encontrados", "success")

    # Descargar con wget
    await send_status(ws, "  → Descargando archivos JS...", "info")
    with open(js_list) as f:
        for url in f:
            url = url.strip()
            if url:
                fname = re.sub(r"[^\w.]", "_", url)[:80] + ".js"
                await stream_command(ws, f"wget -q -O {js_dir / fname} '{url}'")

    # Análisis con patterns propios
    await send_status(ws, "  → Analizando secrets y endpoints...", "info")
    
    secret_patterns = [
        (r'(?i)(api[_\-]?key|apikey)\s*[=:]\s*["\']([A-Za-z0-9\-_]{16,})["\']', "API Key"),
        (r'(?i)(secret|token|password|passwd|pwd)\s*[=:]\s*["\']([A-Za-z0-9\-_!@#$%^&*]{8,})["\']', "Secret/Token"),
        (r'(?i)(aws_access_key_id|aws_secret)\s*[=:]\s*["\']([A-Za-z0-9/+=]{16,})["\']', "AWS Key"),
        (r'(?i)(bearer\s+[A-Za-z0-9\-_=.]{20,})', "Bearer Token"),
        (r'(?i)(private[_\-]?key)\s*[=:]\s*["\']([^\'"]{10,})["\']', "Private Key"),
        (r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', "Email"),
        (r'https?://[a-zA-Z0-9\-_.]+\.[a-zA-Z]{2,}(/[^\s"\']*)?', "URL"),
        (r'(?i)/api/v\d+/[a-zA-Z0-9/_\-]+', "API Endpoint"),
        (r'(?i)(mongodb|postgresql|mysql|redis)://[^\s"\']+', "DB Connection String"),
    ]

    secrets = []
    endpoints = set()

    for js_file in js_dir.glob("*.js"):
        try:
            content = js_file.read_text(errors="replace")
            for pattern, label in secret_patterns:
                matches = re.findall(pattern, content)
                for m in matches:
                    val = m if isinstance(m, str) else m[-1]
                    if label == "API Endpoint":
                        endpoints.add(val)
                    elif label in ("URL",):
                        if any(kw in val for kw in ["/api/", "/v1/", "/v2/", "/graphql", "/rest/"]):
                            endpoints.add(val)
                    elif label not in ("URL", "Email"):
                        secrets.append(f"[{label}] {js_file.name}: {val[:80]}")
        except Exception:
            continue

    # Guardar secrets
    if secrets:
        with open(secrets_file, "w") as f:
            f.write("\n".join(secrets))
        results["secrets_found"] = len(secrets)
        results["files"].append(str(secrets_file))
        await send_status(ws, f"  ⚠ {len(secrets)} posibles secrets encontrados", "warn")

    # Guardar endpoints
    if endpoints:
        with open(endpoints_file, "w") as f:
            f.write("\n".join(sorted(endpoints)))
        results["endpoints_found"] = len(endpoints)
        results["files"].append(str(endpoints_file))
        await send_status(ws, f"  ✔ {len(endpoints)} endpoints extraídos", "success")

    # nuclei si está disponible
    if await tool_exists("nuclei"):
        await send_status(ws, "  → Ejecutando nuclei sobre JS...", "info")
        nuclei_out = audit_dir / "nuclei_js.txt"
        await stream_command(ws, f"nuclei -l {js_list} -t exposures/ -silent -o {nuclei_out}")
        if nuclei_out.exists() and nuclei_out.stat().st_size > 0:
            results["files"].append(str(nuclei_out))

    return results


async def run_web_analysis(ws: WebSocket, target: str, audit_dir: Path) -> dict:
    await send_status(ws, "[+] Iniciando análisis web (headers, tecnologías, fuzzing)...", "info")
    results = {"technologies": [], "vuln_hints": 0, "files": []}

    headers_file = audit_dir / "headers.txt"
    tech_file = audit_dir / "technologies.txt"
    fuzz_file = audit_dir / "fuzz_results.txt"

    base_url = f"https://{target}"

    # Headers con curl
    await send_status(ws, "  → Analizando headers HTTP...", "info")
    await stream_command(ws, f"curl -sI {base_url} | tee {headers_file}")

    if headers_file.exists():
        content = headers_file.read_text()
        security_headers = ["Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options"]
        missing = [h for h in security_headers if h not in content]
        if missing:
            await send_status(ws, f"  ⚠ Headers de seguridad ausentes: {', '.join(missing)}", "warn")
            results["vuln_hints"] += len(missing)

    # whatweb
    if await tool_exists("whatweb"):
        await send_status(ws, "  → Detectando tecnologías con whatweb...", "info")
        await stream_command(ws, f"whatweb -a 3 {base_url} | tee {tech_file}")
        results["files"].append(str(tech_file))

    # ffuf fuzzing básico
    if await tool_exists("ffuf"):
        await send_status(ws, "  → Fuzzing de directorios con ffuf...", "info")
        wordlist = "/usr/share/wordlists/dirb/common.txt"
        if not Path(wordlist).exists():
            wordlist = "/usr/share/seclists/Discovery/Web-Content/common.txt"
        if Path(wordlist).exists():
            await stream_command(
                ws,
                f"ffuf -u {base_url}/FUZZ -w {wordlist} -mc 200,301,302,403 -t 50 -o {fuzz_file} -of json -s",
            )
            if fuzz_file.exists():
                try:
                    data = json.loads(fuzz_file.read_text())
                    hits = len(data.get("results", []))
                    results["vuln_hints"] += hits
                    await send_status(ws, f"  ✔ ffuf encontró {hits} rutas", "success")
                    results["files"].append(str(fuzz_file))
                except Exception:
                    pass
        else:
            await send_status(ws, "  ⚠ Wordlist no encontrada para ffuf", "warn")

    return results


async def generate_summary(ws: WebSocket, target: str, audit_dir: Path, all_results: dict):
    """Genera resumen final consolidado y lo exporta a Markdown."""
    await send_status(ws, "\n[+] Generando resumen final...", "info")

    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    sub = all_results.get("subdomains", {})
    ports = all_results.get("ports", {})
    js = all_results.get("js", {})
    web = all_results.get("web", {})

    summary_lines = [
        f"# ReconKit — Resumen de Auditoría",
        f"**Target:** {target}",
        f"**Fecha:** {date_str}",
        "",
        "---",
        "",
        "## Subdominios",
        f"- Encontrados: **{sub.get('subdomains_found', 0)}**",
        f"- Vivos (httpx): **{sub.get('subdomains_alive', 0)}**",
        "",
        "## Puertos",
        f"- Puertos abiertos: **{ports.get('ports_open', 0)}**",
        f"- Servicios interesantes: **{', '.join(ports.get('interesting_services', [])) or 'Ninguno'}**",
        "",
        "## JavaScript",
        f"- Archivos JS analizados: **{js.get('js_files', 0)}**",
        f"- Posibles secrets: **{js.get('secrets_found', 0)}**",
        f"- Endpoints extraídos: **{js.get('endpoints_found', 0)}**",
        "",
        "## Web",
        f"- Rutas / hallazgos web: **{web.get('vuln_hints', 0)}**",
        "",
        "---",
        "",
        "## Archivos generados",
    ]

    all_files = (
        sub.get("files", [])
        + ports.get("files", [])
        + js.get("files", [])
        + web.get("files", [])
    )
    for f in all_files:
        summary_lines.append(f"- `{f}`")

    summary_md = "\n".join(summary_lines)
    summary_file = audit_dir / "SUMMARY.md"
    summary_file.write_text(summary_md)

    # Enviar resumen al frontend
    await ws.send_json({
        "type": "summary",
        "data": {
            "target": target,
            "date": date_str,
            "subdomains_found": sub.get("subdomains_found", 0),
            "subdomains_alive": sub.get("subdomains_alive", 0),
            "ports_open": ports.get("ports_open", 0),
            "interesting_services": ports.get("interesting_services", []),
            "js_files": js.get("js_files", 0),
            "secrets_found": js.get("secrets_found", 0),
            "endpoints_found": js.get("endpoints_found", 0),
            "vuln_hints": web.get("vuln_hints", 0),
            "audit_dir": str(audit_dir),
            "summary_file": str(summary_file),
        },
    })

    await send_status(ws, f"\n✔ Resumen guardado en: {summary_file}", "success")


async def tool_exists(name: str) -> bool:
    result = await asyncio.create_subprocess_shell(
        f"which {name}",
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    await result.wait()
    return result.returncode == 0


# ─────────────────────────────────────────────
# WebSocket principal
# ─────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            raw = await ws.receive_text()
            msg = json.loads(raw)
            action = msg.get("action")

            if action == "scan":
                target = msg.get("target", "").strip().lower()
                target = re.sub(r"https?://", "", target).rstrip("/")
                modules = msg.get("modules", [])
                port_mode = msg.get("port_mode", "fast")

                if not target:
                    await send_status(ws, "✗ Target vacío", "error")
                    continue

                audit_dir = get_audit_dir(target)
                await send_status(ws, f"\n══ ReconKit iniciado ══", "info")
                await send_status(ws, f"Target: {target}", "info")
                await send_status(ws, f"Directorio: {audit_dir}\n", "info")

                all_results = {}

                if "subdomains" in modules:
                    all_results["subdomains"] = await run_subdomain_enum(ws, target, audit_dir)

                if "ports" in modules:
                    all_results["ports"] = await run_port_scan(ws, target, audit_dir, port_mode)

                if "js" in modules:
                    all_results["js"] = await run_js_analysis(ws, target, audit_dir)

                if "web" in modules:
                    all_results["web"] = await run_web_analysis(ws, target, audit_dir)

                await generate_summary(ws, target, audit_dir, all_results)
                await ws.send_json({"type": "done"})

            elif action == "check_tools":
                tools = ["subfinder", "assetfinder", "httpx", "nmap", "ffuf",
                         "gau", "katana", "nuclei", "whatweb", "curl", "wget"]
                status = {}
                for t in tools:
                    status[t] = await tool_exists(t)
                await ws.send_json({"type": "tools_status", "data": status})

            elif action == "list_audits":
                audits = []
                for d in sorted(AUDITS_DIR.glob("*/*"), reverse=True):
                    if d.is_dir():
                        audits.append({"target": d.parent.name, "date": d.name, "path": str(d)})
                await ws.send_json({"type": "audits_list", "data": audits[:20]})

    except WebSocketDisconnect:
        pass


# ─────────────────────────────────────────────
# Rutas HTTP
# ─────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def root():
    html_file = Path("templates/index.html")
    if html_file.exists():
        return HTMLResponse(html_file.read_text())
    return HTMLResponse("<h1>ReconKit</h1>")


@app.get("/audit/{target}/{date}/summary")
async def get_summary(target: str, date: str):
    f = AUDITS_DIR / target / date / "SUMMARY.md"
    if f.exists():
        return {"content": f.read_text()}
    return {"content": "No encontrado"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
