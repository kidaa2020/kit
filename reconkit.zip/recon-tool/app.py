#!/usr/bin/env python3
"""
ReconKit - Bug Bounty Intelligence Tool
Backend FastAPI con WebSockets para output en tiempo real
"""

import asyncio
import json
import re
from datetime import datetime
from pathlib import Path

import aiohttp
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

app = FastAPI(title="ReconKit")

AUDITS_DIR = Path("audits")
AUDITS_DIR.mkdir(exist_ok=True)

# ══════════════════════════════════════════════════════════
# Helpers de output — mensajes con formato visual
# ══════════════════════════════════════════════════════════

async def log(ws, msg, level="info"):
    await ws.send_json({"type": "status", "level": level, "data": msg})

async def log_output(ws, msg):
    await ws.send_json({"type": "output", "data": msg})

async def log_banner(ws, title):
    bar = "═" * (len(title) + 4)
    await log(ws, f"\n╔{bar}╗", "info")
    await log(ws, f"║  {title}  ║", "info")
    await log(ws, f"╚{bar}╝", "info")

async def log_section(ws, icon, title):
    await log(ws, f"\n┌─ {icon}  {title}", "section")
    await log(ws, f"│", "section")

async def log_step(ws, msg, level="step"):
    await log(ws, f"│  ›  {msg}", level)

async def log_result(ws, msg, level="success"):
    await log(ws, f"│  ✔  {msg}", level)

async def log_warn(ws, msg):
    await log(ws, f"│  ⚠  {msg}", "warn")

async def log_error(ws, msg):
    await log(ws, f"│  ✗  {msg}", "error")

async def log_close(ws):
    await log(ws, f"└{'─'*40}", "section")


# ══════════════════════════════════════════════════════════
# Utilidades
# ══════════════════════════════════════════════════════════

async def run_cmd(ws, cmd, cwd=None, show_output=True):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        cwd=cwd,
    )
    async for line in proc.stdout:
        text = line.decode("utf-8", errors="replace").rstrip()
        if text and show_output:
            await log_output(ws, f"│     {text}")
    await proc.wait()
    return proc.returncode


async def run_cmd_silent(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    out, _ = await proc.communicate()
    return proc.returncode, out.decode("utf-8", errors="replace")


async def tool_exists(name):
    rc, _ = await run_cmd_silent(f"which {name}")
    return rc == 0


def get_audit_dir(target):
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M")
    safe = re.sub(r"[^\w\-.]", "_", target)
    d = AUDITS_DIR / safe / date_str
    d.mkdir(parents=True, exist_ok=True)
    return d


def count_lines(path):
    try:
        return sum(1 for l in open(path) if l.strip())
    except Exception:
        return 0


# ══════════════════════════════════════════════════════════
# MÓDULO 1 — Subdominios
# ══════════════════════════════════════════════════════════

async def run_subdomain_enum(ws, target, audit_dir):
    await log_banner(ws, f"SUBDOMINIOS  ·  {target}")
    results = {"subdomains_found": 0, "subdomains_alive": 0, "files": []}

    subs_file  = audit_dir / "subdomains_raw.txt"
    alive_file = audit_dir / "subdomains_alive.txt"

    # subfinder
    await log_section(ws, "🔍", "subfinder")
    if await tool_exists("subfinder"):
        await log_step(ws, f"Ejecutando subfinder -d {target}")
        await run_cmd(ws, f"subfinder -d {target} -silent -o {subs_file}")
        n = count_lines(subs_file)
        await log_result(ws, f"{n} subdominios encontrados")
    else:
        await log_warn(ws, "subfinder no instalado — saltando")
    await log_close(ws)

    # assetfinder
    await log_section(ws, "🔎", "assetfinder")
    if await tool_exists("assetfinder"):
        await log_step(ws, f"Ejecutando assetfinder --subs-only {target}")
        tmp = audit_dir / "assetfinder_tmp.txt"
        await run_cmd(ws, f"assetfinder --subs-only {target} > {tmp}")
        await run_cmd(ws, f"cat {tmp} >> {subs_file} 2>/dev/null; sort -u {subs_file} -o {subs_file}", show_output=False)
        n = count_lines(subs_file)
        await log_result(ws, f"Total acumulado: {n} subdominios únicos")
    else:
        await log_warn(ws, "assetfinder no instalado — saltando")
    await log_close(ws)

    # crt.sh
    await log_section(ws, "📜", "crt.sh")
    await log_step(ws, f"Consultando crt.sh/?q=%.{target}")
    try:
        async with aiohttp.ClientSession() as session:
            url = f"https://crt.sh/?q=%.{target}&output=json"
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status == 200:
                    data = await resp.json(content_type=None)
                    crt_subs = {
                        entry["name_value"].replace("*.", "").strip()
                        for entry in data
                        if target in entry.get("name_value", "")
                    }
                    with open(subs_file, "a") as f:
                        for s in crt_subs:
                            f.write(s + "\n")
                    await run_cmd(ws, f"sort -u {subs_file} -o {subs_file}", show_output=False)
                    await log_result(ws, f"crt.sh aportó {len(crt_subs)} entradas")
    except Exception as e:
        await log_warn(ws, f"crt.sh falló: {e}")
    await log_close(ws)

    # Deduplicar y contar
    if subs_file.exists():
        total = count_lines(subs_file)
        results["subdomains_found"] = total

    # httpx
    await log_section(ws, "🌐", "httpx — comprobando subdominios vivos")
    if await tool_exists("httpx") and subs_file.exists():
        await log_step(ws, "Filtrando hosts activos con httpx...")
        await run_cmd(
            ws,
            f"httpx -l {subs_file} -silent -o {alive_file} -status-code -title -tech-detect",
        )
        if alive_file.exists():
            alive = count_lines(alive_file)
            results["subdomains_alive"] = alive
            results["files"].append(str(alive_file))
            await log_result(ws, f"{alive} subdominios vivos de {results['subdomains_found']} encontrados")
    else:
        await log_warn(ws, "httpx no disponible o sin subdominios que comprobar")
    await log_close(ws)

    results["files"].append(str(subs_file))
    return results


# ══════════════════════════════════════════════════════════
# MÓDULO 2 — Puertos
# ══════════════════════════════════════════════════════════

async def run_port_scan(ws, target, audit_dir, mode="fast"):
    await log_banner(ws, f"PUERTOS  ·  {target}  ·  modo {mode.upper()}")
    results = {"ports_open": 0, "interesting_services": [], "files": []}

    out_file = audit_dir / "ports.txt"
    xml_file = audit_dir / "ports.xml"

    profiles = {
        "fast":     f"nmap -T4 -F --open -oN {out_file} -oX {xml_file} {target}",
        "full":     f"nmap -T4 -p- --open -sV -oN {out_file} -oX {xml_file} {target}",
        "stealth":  f"nmap -sS -T2 --open -oN {out_file} -oX {xml_file} {target}",
        "services": f"nmap -T4 -p- --open -sV -sC -oN {out_file} -oX {xml_file} {target}",
    }

    await log_section(ws, "🔌", f"nmap — perfil {mode}")
    if not await tool_exists("nmap"):
        await log_error(ws, "nmap no encontrado — instala con: sudo apt install nmap")
        await log_close(ws)
        return results

    await log_step(ws, f"Lanzando: {profiles[mode]}")
    await run_cmd(ws, profiles.get(mode, profiles["fast"]))

    if out_file.exists():
        content = out_file.read_text()
        open_ports = re.findall(r"(\d+)/tcp\s+open\s+(\S+)", content)
        results["ports_open"] = len(open_ports)

        interesting_set = {"8080","8443","9200","6379","27017","5432","3306",
                           "2375","4243","9000","8888","7777","4444","3000",
                           "5000","8008","9090","10000","2049","21","23","25"}
        interesting = [(p, s) for p, s in open_ports if p in interesting_set]
        results["interesting_services"] = [p for p, _ in interesting]
        results["files"].append(str(out_file))

        await log_result(ws, f"{len(open_ports)} puertos abiertos encontrados")
        for port, svc in open_ports[:20]:
            marker = "  ⚠" if port in interesting_set else "   "
            await log_output(ws, f"│     {marker}  {port}/tcp  →  {svc}")
        if len(open_ports) > 20:
            await log_output(ws, f"│     ... y {len(open_ports)-20} más (ver {out_file.name})")
        if interesting:
            await log_warn(ws, f"Puertos sensibles detectados: {', '.join(p for p,_ in interesting)}")
    await log_close(ws)

    return results


# ══════════════════════════════════════════════════════════
# MÓDULO 3 — JavaScript
# ══════════════════════════════════════════════════════════

async def run_js_analysis(ws, target, audit_dir):
    await log_banner(ws, f"JAVASCRIPT  ·  {target}")
    results = {"js_files": 0, "secrets_found": 0, "endpoints_found": 0, "files": []}

    js_dir        = audit_dir / "js_files"
    js_dir.mkdir(exist_ok=True)
    js_list       = audit_dir / "js_urls.txt"
    secrets_file  = audit_dir / "secrets.txt"
    endpoints_file= audit_dir / "endpoints.txt"

    # ── Fase 1: descubrir URLs de JS ──────────────────────

    await log_section(ws, "🕸️", "Descubrimiento de archivos JS")

    # gau — wayback + otx + commoncrawl
    if await tool_exists("gau"):
        await log_step(ws, f"gau {target} (wayback, otx, commoncrawl)...")
        tmp_gau = audit_dir / "gau_tmp.txt"
        await run_cmd(
            ws,
            f"gau {target} --blacklist png,jpg,gif,svg,woff,ttf,eot,css 2>/dev/null | grep -E '\\.js(\\?|$)' | sort -u > {tmp_gau}",
            show_output=False,
        )
        if tmp_gau.exists():
            n = count_lines(tmp_gau)
            await run_cmd(ws, f"cat {tmp_gau} >> {js_list} 2>/dev/null", show_output=False)
            await log_result(ws, f"gau encontró {n} URLs de JS")
    else:
        await log_warn(ws, "gau no instalado — saltando wayback/otx")

    # katana — crawl activo + JS dinámico
    if await tool_exists("katana"):
        await log_step(ws, f"katana https://{target} (crawl activo + JS parsing)...")
        tmp_katana = audit_dir / "katana_tmp.txt"
        await run_cmd(
            ws,
            f"katana -u https://{target} -silent -jc -d 3 -o {tmp_katana} 2>/dev/null",
            show_output=False,
        )
        if tmp_katana.exists():
            # Filtrar solo JS
            await run_cmd(
                ws,
                f"grep -E '\\.js(\\?|$)' {tmp_katana} >> {js_list} 2>/dev/null",
                show_output=False,
            )
            n_katana = count_lines(tmp_katana)
            await log_result(ws, f"katana crawleó {n_katana} URLs totales")
    else:
        await log_warn(ws, "katana no instalado — saltando crawl activo")

    # Fallback con curl si ninguna herramienta dio resultados
    if not js_list.exists() or count_lines(js_list) == 0:
        await log_step(ws, f"Fallback: extrayendo JS con curl desde https://{target}")
        rc, html = await run_cmd_silent(f"curl -sk --max-time 15 https://{target}")
        if rc == 0:
            js_urls = re.findall(r'src=["\']([^"\']*\.js[^"\']*)["\']', html)
            found = []
            for u in js_urls:
                if u.startswith("http"):
                    found.append(u)
                elif u.startswith("//"):
                    found.append("https:" + u)
                elif u.startswith("/"):
                    found.append(f"https://{target}{u}")
                else:
                    found.append(f"https://{target}/{u}")
            if found:
                with open(js_list, "w") as f:
                    f.write("\n".join(set(found)) + "\n")
                await log_result(ws, f"curl extrajo {len(set(found))} archivos JS de la página principal")

    # Deduplicar lista final
    if js_list.exists():
        await run_cmd(ws, f"sort -u {js_list} -o {js_list}", show_output=False)

    total_js = count_lines(js_list) if js_list.exists() else 0
    if total_js == 0:
        await log_warn(ws, "No se encontraron archivos JS")
        await log_close(ws)
        return results

    await log_result(ws, f"Total: {total_js} archivos JS únicos para analizar")
    await log_close(ws)

    # ── Fase 2: descargar JS ──────────────────────────────

    await log_section(ws, "⬇️", f"Descargando {total_js} archivos JS")
    downloaded = 0
    failed = 0

    with open(js_list) as f:
        urls = [l.strip() for l in f if l.strip()]

    for url in urls:
        # nombre de archivo limpio y único
        fname = re.sub(r"https?://", "", url)
        fname = re.sub(r"[^\w.]", "_", fname)[:100] + ".js"
        out_path = js_dir / fname

        rc, _ = await run_cmd_silent(
            f"curl -sk --max-time 20 -L -o '{out_path}' '{url}'"
        )
        if rc == 0 and out_path.exists() and out_path.stat().st_size > 0:
            downloaded += 1
            await log_output(ws, f"│     ✔  {url[:70]}")
        else:
            failed += 1
            await log_output(ws, f"│     ✗  {url[:70]}")

    results["js_files"] = downloaded
    await log_result(ws, f"{downloaded} descargados  ·  {failed} fallidos")
    await log_close(ws)

    # ── Fase 3: análisis de contenido ────────────────────

    await log_section(ws, "🔬", "Análisis de secrets y endpoints")

    secret_patterns = [
        (r'(?i)(api[_\-]?key|apikey)\s*[=:]\s*["\']([A-Za-z0-9\-_]{16,})["\']',          "API Key"),
        (r'(?i)(secret|token|password|passwd|pwd)\s*[=:]\s*["\']([A-Za-z0-9\-_!@#$%^&*]{8,})["\']', "Secret/Token"),
        (r'(?i)(aws_access_key_id)\s*[=:]\s*["\']([A-Z0-9]{20})["\']',                    "AWS Access Key"),
        (r'(?i)(aws_secret_access_key)\s*[=:]\s*["\']([A-Za-z0-9/+=]{40})["\']',          "AWS Secret Key"),
        (r'(?i)bearer\s+([A-Za-z0-9\-_=.]{20,})',                                          "Bearer Token"),
        (r'(?i)(private[_\-]?key)\s*[=:]\s*["\']([^\'"]{10,})["\']',                      "Private Key"),
        (r'(mongodb|postgresql|mysql|redis|amqp)://[^\s"\'<>]+',                            "DB Connection String"),
        (r'(?i)(client[_\-]?id|client[_\-]?secret)\s*[=:]\s*["\']([A-Za-z0-9\-_]{8,})["\']', "OAuth Credential"),
        (r'(?i)(slack|discord|telegram)[_\-]?(token|webhook|bot)\s*[=:]\s*["\']([^\'"]{10,})["\']', "Messaging Token"),
        (r'AIza[0-9A-Za-z\-_]{35}',                                                        "Google API Key"),
        (r'ghp_[A-Za-z0-9]{36}',                                                           "GitHub Token"),
        (r'xox[baprs]-[A-Za-z0-9\-]+',                                                     "Slack Token"),
    ]

    endpoint_patterns = [
        r'(?i)["\'](/api/v\d+/[a-zA-Z0-9/_\-?=&]+)["\']',
        r'(?i)["\'](/graphql[^\s"\']*)["\']',
        r'(?i)["\'](/rest/[a-zA-Z0-9/_\-]+)["\']',
        r'(?i)["\'](/v\d+/[a-zA-Z0-9/_\-]+)["\']',
        r'(?i)fetch\(["\']([^\s"\']+)["\']',
        r'(?i)axios\.[a-z]+\(["\']([^\s"\']+)["\']',
        r'(?i)url\s*[=:]\s*["\']([^\s"\']{5,})["\']',
    ]

    secrets   = []
    endpoints = set()

    js_files_list = list(js_dir.glob("*.js"))
    await log_step(ws, f"Analizando {len(js_files_list)} archivos localmente...")

    for js_file in js_files_list:
        try:
            content = js_file.read_text(errors="replace")

            for pattern, label in secret_patterns:
                for m in re.finditer(pattern, content):
                    val = m.group(0)
                    secrets.append(f"[{label}] {js_file.name}:  {val[:100]}")

            for pattern in endpoint_patterns:
                for m in re.finditer(pattern, content):
                    ep = m.group(1)
                    if len(ep) > 3 and not ep.endswith((".png",".jpg",".css",".woff")):
                        endpoints.add(ep)
        except Exception:
            continue

    # Guardar secrets
    if secrets:
        with open(secrets_file, "w") as f:
            f.write("\n".join(dict.fromkeys(secrets)))  # deduplicar manteniendo orden
        results["secrets_found"] = len(secrets)
        results["files"].append(str(secrets_file))
        await log_warn(ws, f"{len(secrets)} posibles secrets encontrados → {secrets_file.name}")
        for s in secrets[:5]:
            await log_output(ws, f"│     ⚠  {s[:90]}")
        if len(secrets) > 5:
            await log_output(ws, f"│     ... y {len(secrets)-5} más en {secrets_file.name}")
    else:
        await log_result(ws, "No se encontraron secrets conocidos")

    # Guardar endpoints
    if endpoints:
        with open(endpoints_file, "w") as f:
            f.write("\n".join(sorted(endpoints)))
        results["endpoints_found"] = len(endpoints)
        results["files"].append(str(endpoints_file))
        await log_result(ws, f"{len(endpoints)} endpoints extraídos → {endpoints_file.name}")
        for ep in sorted(endpoints)[:8]:
            await log_output(ws, f"│      →  {ep}")
        if len(endpoints) > 8:
            await log_output(ws, f"│     ... y {len(endpoints)-8} más")
    else:
        await log_result(ws, "No se encontraron endpoints en los JS")
    await log_close(ws)

    # ── Fase 4: nuclei sobre JS ───────────────────────────
    if await tool_exists("nuclei") and js_list.exists():
        await log_section(ws, "☢️", "nuclei — análisis de exposiciones en JS")
        nuclei_out = audit_dir / "nuclei_js.txt"
        await log_step(ws, "Ejecutando plantillas de exposures/...")
        await run_cmd(
            ws,
            f"nuclei -l {js_list} -t exposures/ -t exposures/tokens/ -silent -o {nuclei_out} 2>/dev/null",
        )
        if nuclei_out.exists() and nuclei_out.stat().st_size > 0:
            n = count_lines(nuclei_out)
            await log_warn(ws, f"nuclei encontró {n} hallazgos → {nuclei_out.name}")
            results["files"].append(str(nuclei_out))
        else:
            await log_result(ws, "nuclei no encontró exposiciones")
        await log_close(ws)

    results["files"].append(str(js_list))
    return results


# ══════════════════════════════════════════════════════════
# MÓDULO 4 — Web
# ══════════════════════════════════════════════════════════

async def run_web_analysis(ws, target, audit_dir):
    await log_banner(ws, f"ANÁLISIS WEB  ·  {target}")
    results = {"technologies": [], "vuln_hints": 0, "files": []}

    headers_file = audit_dir / "headers.txt"
    tech_file    = audit_dir / "technologies.txt"
    fuzz_file    = audit_dir / "fuzz_results.txt"
    base_url     = f"https://{target}"

    # Headers
    await log_section(ws, "📋", "Headers HTTP de seguridad")
    await log_step(ws, f"curl -sI {base_url}")
    await run_cmd(ws, f"curl -sI --max-time 10 {base_url} | tee {headers_file}")

    if headers_file.exists():
        content = headers_file.read_text()
        sec_headers = [
            "Strict-Transport-Security",
            "Content-Security-Policy",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "Permissions-Policy",
            "Referrer-Policy",
        ]
        missing = [h for h in sec_headers if h.lower() not in content.lower()]
        present = [h for h in sec_headers if h.lower() in content.lower()]
        for h in present:
            await log_result(ws, f"Presente:  {h}")
        for h in missing:
            await log_warn(ws,  f"Ausente:   {h}")
        results["vuln_hints"] += len(missing)
    await log_close(ws)

    # whatweb
    await log_section(ws, "🛠️", "Detección de tecnologías — whatweb")
    if await tool_exists("whatweb"):
        await log_step(ws, f"whatweb -a 3 {base_url}")
        await run_cmd(ws, f"whatweb -a 3 {base_url} | tee {tech_file}")
        results["files"].append(str(tech_file))
    else:
        await log_warn(ws, "whatweb no instalado")
    await log_close(ws)

    # ffuf
    await log_section(ws, "💥", "Fuzzing de directorios — ffuf")
    if await tool_exists("ffuf"):
        wordlists = [
            "/usr/share/seclists/Discovery/Web-Content/common.txt",
            "/usr/share/wordlists/dirb/common.txt",
            "/usr/share/wordlists/dirbuster/directory-list-2.3-small.txt",
        ]
        wl = next((w for w in wordlists if Path(w).exists()), None)
        if wl:
            await log_step(ws, f"ffuf con {Path(wl).name} · 50 threads")
            await run_cmd(
                ws,
                f"ffuf -u {base_url}/FUZZ -w {wl} -mc 200,201,204,301,302,403 -t 50 -o {fuzz_file} -of json -s",
            )
            if fuzz_file.exists():
                try:
                    data = json.loads(fuzz_file.read_text())
                    hits = data.get("results", [])
                    results["vuln_hints"] += len(hits)
                    await log_result(ws, f"{len(hits)} rutas encontradas")
                    for h in hits[:10]:
                        await log_output(ws, f"│      →  [{h.get('status')}]  {h.get('url','')}")
                    if len(hits) > 10:
                        await log_output(ws, f"│     ... y {len(hits)-10} más en {fuzz_file.name}")
                    results["files"].append(str(fuzz_file))
                except Exception:
                    pass
        else:
            await log_warn(ws, "Wordlist no encontrada — instala seclists: sudo apt install seclists")
    else:
        await log_warn(ws, "ffuf no instalado")
    await log_close(ws)

    return results


# ══════════════════════════════════════════════════════════
# RESUMEN FINAL
# ══════════════════════════════════════════════════════════

async def generate_summary(ws, target, audit_dir, all_results):
    await log_banner(ws, "RESUMEN FINAL")

    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    sub   = all_results.get("subdomains", {})
    ports = all_results.get("ports",      {})
    js    = all_results.get("js",         {})
    web   = all_results.get("web",        {})

    lines = [
        "╔══════════════════════════════════════════════╗",
        f"║  TARGET  :  {target:<33}║",
        f"║  FECHA   :  {date_str:<33}║",
        "╠══════════════════════════════════════════════╣",
        f"║  🌐 Subdominios encontrados  :  {sub.get('subdomains_found',0):<14}║",
        f"║  🌐 Subdominios vivos        :  {sub.get('subdomains_alive',0):<14}║",
        "╠══════════════════════════════════════════════╣",
        f"║  🔌 Puertos abiertos         :  {ports.get('ports_open',0):<14}║",
        f"║  🔌 Servicios sensibles      :  {', '.join(ports.get('interesting_services',[])) or 'Ninguno':<14}║",
        "╠══════════════════════════════════════════════╣",
        f"║  ⚡ Archivos JS analizados   :  {js.get('js_files',0):<14}║",
        f"║  ⚡ Endpoints extraídos      :  {js.get('endpoints_found',0):<14}║",
        f"║  ⚡ Posibles secrets         :  {js.get('secrets_found',0):<14}║",
        "╠══════════════════════════════════════════════╣",
        f"║  🔍 Hallazgos web / rutas    :  {web.get('vuln_hints',0):<14}║",
        "╠══════════════════════════════════════════════╣",
        f"║  📁 Resultados en: {str(audit_dir)[:27]:<27}║",
        "╚══════════════════════════════════════════════╝",
    ]

    for line in lines:
        level = "warn" if ("secrets" in line and js.get("secrets_found",0) > 0) else "summary"
        await log(ws, line, level)

    # Guardar markdown
    md_lines = [
        f"# ReconKit — Auditoría {target}",
        f"**Fecha:** {date_str}  |  **Target:** {target}",
        "",
        "## Subdominios",
        f"- Encontrados: **{sub.get('subdomains_found',0)}**",
        f"- Vivos: **{sub.get('subdomains_alive',0)}**",
        "",
        "## Puertos",
        f"- Abiertos: **{ports.get('ports_open',0)}**",
        f"- Sensibles: **{', '.join(ports.get('interesting_services',[])) or 'Ninguno'}**",
        "",
        "## JavaScript",
        f"- Archivos JS: **{js.get('js_files',0)}**",
        f"- Endpoints: **{js.get('endpoints_found',0)}**",
        f"- Secrets: **{js.get('secrets_found',0)}**",
        "",
        "## Web",
        f"- Hallazgos: **{web.get('vuln_hints',0)}**",
        "",
        "## Archivos generados",
    ]
    all_files = (sub.get("files",[]) + ports.get("files",[]) +
                 js.get("files",[]) + web.get("files",[]))
    for f in all_files:
        md_lines.append(f"- `{f}`")

    summary_file = audit_dir / "SUMMARY.md"
    summary_file.write_text("\n".join(md_lines))
    await log(ws, f"\n  📄 SUMMARY.md guardado en: {summary_file}", "success")

    # Enviar datos al panel de resumen del frontend
    await ws.send_json({
        "type": "summary",
        "data": {
            "target": target, "date": date_str,
            "subdomains_found":    sub.get("subdomains_found", 0),
            "subdomains_alive":    sub.get("subdomains_alive", 0),
            "ports_open":          ports.get("ports_open", 0),
            "interesting_services":ports.get("interesting_services", []),
            "js_files":            js.get("js_files", 0),
            "secrets_found":       js.get("secrets_found", 0),
            "endpoints_found":     js.get("endpoints_found", 0),
            "vuln_hints":          web.get("vuln_hints", 0),
            "audit_dir":           str(audit_dir),
            "summary_file":        str(summary_file),
        },
    })


# ══════════════════════════════════════════════════════════
# WebSocket principal
# ══════════════════════════════════════════════════════════

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            raw  = await ws.receive_text()
            msg  = json.loads(raw)
            action = msg.get("action")

            if action == "scan":
                target = re.sub(r"https?://", "", msg.get("target","").strip().lower()).rstrip("/")
                if not target:
                    await log(ws, "✗ Target vacío", "error")
                    continue

                modules   = msg.get("modules", [])
                port_mode = msg.get("port_mode", "fast")
                audit_dir = get_audit_dir(target)
                all_results = {}

                if "subdomains" in modules:
                    all_results["subdomains"] = await run_subdomain_enum(ws, target, audit_dir)
                if "ports" in modules:
                    all_results["ports"] = await run_port_scan(ws, target, audit_dir, port_mode)
                if "js" in modules:
                    all_results["js"] = await run_js_analysis(ws, target, audit_dir)
                if "web" in modules:
                    all_results["web"] = await run_web_analysis(ws, target, audit_dir)

                await generate_summary(ws, target, audit_dir, all_results)
                await ws.send_json({"type": "done"})

            elif action == "check_tools":
                tools = ["subfinder","assetfinder","httpx","nmap","ffuf",
                         "gau","katana","nuclei","whatweb","curl","wget"]
                await ws.send_json({
                    "type": "tools_status",
                    "data": {t: await tool_exists(t) for t in tools}
                })

            elif action == "list_audits":
                audits = [
                    {"target": d.parent.name, "date": d.name, "path": str(d)}
                    for d in sorted(AUDITS_DIR.glob("*/*"), reverse=True)
                    if d.is_dir()
                ]
                await ws.send_json({"type": "audits_list", "data": audits[:20]})

    except WebSocketDisconnect:
        pass


# ══════════════════════════════════════════════════════════
# HTTP
# ══════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse)
async def root():
    f = Path("templates/index.html")
    return HTMLResponse(f.read_text() if f.exists() else "<h1>ReconKit</h1>")


@app.get("/audit/{target}/{date}/summary")
async def get_summary(target: str, date: str):
    f = AUDITS_DIR / target / date / "SUMMARY.md"
    return {"content": f.read_text() if f.exists() else "No encontrado"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
