#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
#  ReconKit — Instalador de dependencias
#  Ejecuta automáticamente en el primer arranque
# ═══════════════════════════════════════════════════════════

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'; CYAN='\033[0;36m'

ok()   { echo -e "${GREEN}[✔]${NC} $1"; }
warn() { echo -e "${YELLOW}[⚠]${NC} $1"; }
info() { echo -e "${CYAN}[→]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; }

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ReconKit — Instalando dependencias     ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── Python deps ─────────────────────────────────────────────
info "Instalando dependencias Python..."
pip install fastapi uvicorn websockets aiofiles aiohttp --break-system-packages -q
ok "Python deps instaladas"

# ── Función de instalación de herramientas Go ────────────────
install_go_tool() {
    local name=$1
    local pkg=$2
    if command -v "$name" &>/dev/null; then
        ok "$name ya instalado"
    else
        info "Instalando $name..."
        if command -v go &>/dev/null; then
            go install "$pkg@latest" 2>/dev/null && ok "$name instalado" || warn "$name falló al instalar"
        else
            warn "Go no encontrado — $name no se instalará. Instala Go: https://go.dev/dl/"
        fi
    fi
}

# ── Go tools ────────────────────────────────────────────────
install_go_tool "subfinder"   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
install_go_tool "httpx"       "github.com/projectdiscovery/httpx/cmd/httpx"
install_go_tool "katana"      "github.com/projectdiscovery/katana/cmd/katana"
install_go_tool "nuclei"      "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
install_go_tool "gau"         "github.com/lc/gau/v2/cmd/gau"
install_go_tool "assetfinder" "github.com/tomnomnom/assetfinder"
install_go_tool "dnsx"        "github.com/projectdiscovery/dnsx/cmd/dnsx"

# ── Apt tools ───────────────────────────────────────────────
APT_TOOLS=("nmap" "ffuf" "whatweb" "curl" "wget" "jq")
for tool in "${APT_TOOLS[@]}"; do
    if command -v "$tool" &>/dev/null; then
        ok "$tool ya instalado"
    else
        info "Instalando $tool vía apt..."
        sudo apt-get install -y "$tool" -qq 2>/dev/null && ok "$tool instalado" || warn "$tool no se pudo instalar"
    fi
done

# ── SecLists ─────────────────────────────────────────────────
if [ ! -d "/usr/share/seclists" ]; then
    info "Instalando SecLists (wordlists para ffuf)..."
    sudo apt-get install -y seclists -qq 2>/dev/null || warn "SecLists no disponible vía apt"
else
    ok "SecLists ya instalado"
fi

# ── Nuclei templates ─────────────────────────────────────────
if command -v nuclei &>/dev/null; then
    info "Actualizando templates de nuclei..."
    nuclei -update-templates -silent 2>/dev/null && ok "Nuclei templates actualizados" || warn "No se pudieron actualizar templates"
fi

# ── Marcar instalación completa ─────────────────────────────
touch .installed
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Instalación completada ✔               ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
